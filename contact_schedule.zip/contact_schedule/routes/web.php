<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});

Auth::routes();

Route::get('/home', 'ContactController@index')->name('home');

Route::group(['as' => 'contact.', 'prefix' => 'contact'], function(){
    Route::get('', ['as' => 'index', 'uses' => 'ContactController@index']);

    Route::get('create', ['as' => 'create', 'uses' => 'ContactController@create']);
    Route::post('create', ['as' => 'store', 'uses' => 'ContactController@store']);

    Route::get('{id}/edit', ['as' => 'edit', 'uses' => 'ContactController@edit']);
    Route::post('{id}/edit', ['as' => 'update', 'uses' => 'ContactController@update']);

    Route::get('{id}/delete', ['as' => 'delete', 'uses' => 'ContactController@delete']);
});

Route::group(['as' => 'user.', 'prefix' => 'user'], function(){
    Route::get('', ['as' => 'index', 'uses' => 'UserController@index']);
    Route::get('{id}/perfil', ['as' => 'perfil', 'uses' => 'UserController@perfil']);

    Route::post('{id}/edit', ['as' => 'update', 'uses' => 'UserController@update']);

    Route::post('{id}/delete', ['as' => 'delete', 'uses' => 'UserController@delete']);
});