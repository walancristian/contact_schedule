@extends('layouts.app')

@section('page_title', 'Editar Cadastro')

@section('content')

<div class="container">
    @if(session('error'))
        <div class="full-width">
            <div class="alert alert-danger">
                <i class="fa fa-check"></i> <b>{!! session('error') !!}</b>
            </div>
        </div>
    @endif

    <div class="col-sm-12">
        <a href="/home">
            <button type="button" class="btn btn-primary">VOLTAR</button>
        </a>
    </div>

    <div class="col-md-6 col-md-offset-3">
        <div class="panel">
            <div class="panel-heading" style="margin-top: -5%;">
                <h3><b>EDITAR CONTATO</b></h3>
            </div>

            <div class="panel-body">
                <form method="post" action="{{ route('contact.update', ['id' => $contact->id]) }}">
                    <div class="form-group col-sm-12">
                        <label>Nome:</label>   
                        <input type="text" class="form-control input" name="name" maxlength="50" value="{{ $contact->name }}">
                    </div>

                    <div class="form-group col-sm-12"> 
                        <label>E-mail:</label>  
                        <input type="text" class="form-control input" name="email" maxlength="50" value="{{ $contact->email }}">      
                    </div>

                    <div class="form-group col-md-6"> 
                        <label>Telefone:</label>  
                        <input id="telefone" type="text" class="form-control input" name="phone" maxlength="15" value="{{ $contact->phone }}">
                    </div>

                    <div class="form-group col-md-6">
                        <label>Data de Nascimento:</label>   
                        <input type="date" class="form-control input" name="birthday" value="{{ $contact->birthday }}">
                    </div>

                    <div class="form-group col-sm-12">
                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                        <input type="submit" name="btn" class="btn btn-primary" value="ATUALIZAR">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection