@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-6 col-sm-offset-3">
            <div class="panel">
                <div class="panel-heading">
                    <h3><b>LOGIN</b></h3>
                </div>

                <div id="panel-login" class="panel-body">
                    <form method="POST" action="{{ route('login') }}">
                        {{ csrf_field() }}

                        <div class="form-group">
                            <div class="col-sm-8 col-sm-offset-2">
                                <div class="checkbox" style="float: right; margin-bottom: -6%;">
                                    <label>
                                        <input type="checkbox" name="remember" {{ old('remember') ? 'checked' : '' }}> Lembre-me
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }} col-sm-8 col-sm-offset-2">
                            <label for="email" class="control-label">E-Mail:</label>

                            <input id="email" type="email" class="form-control input" name="email" value="{{ old('email') }}" required autofocus>

                            @if ($errors->has('email'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('email') }}</strong>
                                </span>
                            @endif
                        </div>

                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }} col-sm-8 col-sm-offset-2">
                            <label for="password" class="control-label">Senha:</label>

                            <input id="password" type="password" class="form-control input" name="password" required>

                            @if ($errors->has('password'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('password') }}</strong>
                                </span>
                            @endif
                        </div>

                        <div class="form-group">
                            <div class="col-sm-8 col-sm-offset-2" style="margin-top: 5%;">
                                <button type="submit" class="btn btn-primary">
                                    Login
                                </button>

                                <a class="btn-link" style="margin-left: 5%;" href="{{ route('password.request') }}">
                                    Esqueceu sua senha?
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
