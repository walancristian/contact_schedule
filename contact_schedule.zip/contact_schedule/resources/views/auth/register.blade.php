@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-sm-6 col-sm-offset-3">
            <div class="panel">
                <div class="panel-heading">
                    <h3><b>REGISTRAR</b></h3>
                </div>

                <div id="panel-register" class="panel-body">
                    <form method="POST" action="{{ route('register') }}">
                        {{ csrf_field() }}

                        <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }} col-sm-12">
                            <label for="name" class="control-label">Nome:</label>

                            <div>
                                <input id="name" type="text" class="form-control input" name="name" value="{{ old('name') }}" required autofocus>

                                @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }} col-sm-12">
                            <label for="email" class="control-label">E-Mail:</label>

                            <div>
                                <input id="email" type="email" class="form-control input" name="email" value="{{ old('email') }}" required>

                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }} col-md-6">
                            <label for="password" class="control-label">Senha:</label>

                            <div>
                                <input id="password" type="password" class="form-control input" name="password" minlength="8" maxlength="20" placeholder="Mínimo 8 dígitos" required>

                                @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group col-md-6">
                            <label for="password-confirm" class="control-label">Confirmar Senha:</label>

                            <div>
                                <input id="password-confirm" type="password" class="form-control input" name="password_confirmation" minlength="8" maxlength="20" placeholder="Mínimo 8 dígitos" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-sm-4 col-sm-offset-4" style="text-align: center; margin-top: 5%;">
                                <button type="submit" class="btn btn-primary">
                                    Registrar-se
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
