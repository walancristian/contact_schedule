@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-sm-6 col-md-offset-3">
            <div class="panel">
                <div class="panel-heading">
                    <h3 class="col-sm-12"><b>RECUPERAR SENHA</b></h3>
                </div>

                <div class="panel-body">
                    <form method="POST" action="{{ route('password.request') }}">
                        {{ csrf_field() }}

                        <input type="hidden" name="token" value="{{ $token }}">

                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }} col-sm-12">
                            <label for="email" class="control-label">E-Mail:</label>

                            <div>
                                <input id="email" type="email" class="form-control input" name="email" value="{{ $email or old('email') }}" required autofocus>

                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }} col-md-6">
                            <label for="password" class="control-label">Senha:</label>

                            <div>
                                <input id="password" type="password" class="form-control input" name="password" minlength="8" maxlength="20" placeholder="Mínimo 8 dígitos" required>

                                @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('password_confirmation') ? ' has-error' : '' }} col-md-6">
                            <label for="password-confirm" class="control-label">Confirmar Senha:</label>
                            <div>
                                <input id="password-confirm" type="password" class="form-control input" name="password_confirmation" minlength="8" maxlength="20" placeholder="Mínimo 8 dígitos" required>

                                @if ($errors->has('password_confirmation'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password_confirmation') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-sm-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Recuperar Senha
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
