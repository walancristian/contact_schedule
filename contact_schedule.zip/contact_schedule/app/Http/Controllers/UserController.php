<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;
use App\Contact;
use Hash;

class UserController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

    public function perfil($id)
    {
        $user = User::find($id);
        if(!$user){
            abort(404);
        }

        return view('users.perfil', compact('user'));
    }

    public function update(Request $request, $id)
    {
        $this->validate($request, [
                'password' => 'required|min:8',
                'nome' => 'required',
                'email' => 'required',
        ]);

        $user = User::find($id);

        if(Hash::check($request->password, $user->password))
        {  
            $user->name = $request->name;
            $user->email = $request->email;

            if ($request->newpassword != null) {
                $user->password = bcrypt($request->newpassword);
            }

            $user->save();

            return redirect()->route('user.perfil', ['id' => $user->id])->with('status', 'Perfil editado com sucesso!');
        }

        return redirect()->back()->with('error', 'Erro ao editar perfil!');
    }

    public function delete(Request $request, $id)
    {
        $this->validate($request, [
                'password' => 'required|min:8',
                'reason' => 'required',
        ]);

        $user = User::find($id);

        if((Hash::check($request->password, $user->password)) && ($request->reason != null))
        {   
            $user->deleted_reason = $request->reason;
            $user->save();

            $user->delete();        

            return redirect('/');
        }

        return redirect()->back()->with('error', 'Erro ao excluir perfil!');
    }
}
