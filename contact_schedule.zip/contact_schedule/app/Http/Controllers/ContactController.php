<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;
use App\Contact;

class ContactController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $contacts = Contact::orderBy('name');

        if($request->name != null)
        {
            if($request->has('name')){
                $contacts->where("name", "like", "%{$request->name}%");
            }
        }

        if($request->phone != null)
        {
            if($request->has('phone')){
                $contacts->where("phone", "like", "%{$request->phone}%");
            }
        }

        $contacts = $contacts->paginate(20);

        return view('contacts.index', compact('contacts'));
    }

    public function create()
    {
        return view ('contacts.create');
    }

    public function store(Request $request)
    {
        $this->validate($request, [
                'name' => 'required',
                'email' => 'required',
                'phone' => 'required|max:15',
                'birthday' => 'required',
        ]);

        $count_contact = Contact::where('name', $request->name)
                                ->where('phone', $request->phone)
                                ->count();
        
        if ($count_contact == 0)
        {
            $contact = new Contact;

            $contact->name = $request->name;
            $contact->email = $request->email;
            $contact->phone = $request->phone;
            $contact->birthday = $request->birthday;
            $contact->save();

            return redirect()->route('contact.index')->with('status', 'Contato adicionado a agenda com sucesso!');
        } else {
            return redirect()->back()->with('error', 'Erro ao adicionar o contato na agenda!');
        }
    }

    public function edit($id)
    {
        $contact = Contact::find($id);
        if(!$contact){
            abort(404);
        }

        return view('contacts.edit', compact('contact'));
    }

    public function update(Request $request, $id)
    {
        $this->validate($request, [
                'name' => 'required',
                'email' => 'required',
                'phone' => 'required|max:15',
                'birthday' => 'required',
        ]);

        $count_contact = Contact::where('id', '!=', $id)
                                ->where('name', $request->name)
                                ->where('phone', $request->phone)
                                ->count();
        
        if ($count_contact == 0)
        {
            $contact = Contact::find($id);
        
            $contact->name = $request->name;
            $contact->email = $request->email;
            $contact->phone = $request->phone;
            $contact->birthday = $request->birthday;
            $contact->save();

            return redirect()->route('contact.index')->with('status', 'Contato editado com sucesso!');
        } else {
            return redirect()->back()->with('error', 'Erro ao editar o contato!');
        }
    }

    public function delete($id)
    {
        $contact = Contact::find($id);

        $contact->deleted_user = \Auth::user()->id;
        $contact->save();

        if($contact->delete())
        {
            return redirect()->route('contact.index')->with('status', 'Contato excluido da agenda com sucesso!');
        }

        return redirect()->route('contact.index')->with('error', 'Erro ao excluir o contato da agenda!');
    }
}
