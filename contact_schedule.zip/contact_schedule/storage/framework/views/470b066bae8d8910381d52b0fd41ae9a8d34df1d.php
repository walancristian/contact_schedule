<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-6 col-sm-offset-3">
            <div class="panel">
                <div class="panel-heading">
                    <h3><b>REGISTRAR</b></h3>
                </div>

                <div id="panel-register" class="panel-body">
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?> col-sm-12">
                            <label for="name" class="control-label">Nome:</label>

                            <div>
                                <input id="name" type="text" class="form-control input" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?> col-sm-12">
                            <label for="email" class="control-label">E-Mail:</label>

                            <div>
                                <input id="email" type="email" class="form-control input" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?> col-md-6">
                            <label for="password" class="control-label">Senha:</label>

                            <div>
                                <input id="password" type="password" class="form-control input" name="password" minlength="8" maxlength="20" placeholder="Mínimo 8 dígitos" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group col-md-6">
                            <label for="password-confirm" class="control-label">Confirmar Senha:</label>

                            <div>
                                <input id="password-confirm" type="password" class="form-control input" name="password_confirmation" minlength="8" maxlength="20" placeholder="Mínimo 8 dígitos" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-sm-4 col-sm-offset-4" style="text-align: center; margin-top: 5%;">
                                <button type="submit" class="btn btn-primary">
                                    Registrar-se
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>