<?php $__env->startSection('page_title', 'Detalhes Cadastro'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">    
    <!-- <div class="col-sm-12">
        <a href="/home">
            <button type="button" class="btn btn-primary">VOLTAR</button>
        </a>
    </div> -->

    <div class="col-md-6 col-md-offset-3">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3><b>CONTATO #<?php echo e($contact->id); ?></b></h3>
            </div>

            <div class="panel-body">
                <form method="post" action="">
                    <div class="form-group col-sm-6">
                        <strong>Nome:</strong><?php echo e($contact->name); ?>

                    </div>

                    <div class="form-group col-sm-6"> 
                        <strong>E-mail:</strong><?php echo e($contact->email); ?>      
                    </div>

                    <div class="form-group col-sm-6"> 
                        <strong>Telefone:</strong><?php echo e($contact->phone); ?>

                    </div>

                    <div class="form-group col-sm-6">
                        <strong>Data de Nascimento:</strong><?php echo e($contact->birthday); ?>

                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>