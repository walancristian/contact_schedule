<?php $__env->startSection('page_title', 'Buscar Cadastro'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <?php if(session('status')): ?>
        <div class="full-width">
            <div class="alert alert-success">
                <i class="fa fa-check"></i> <b><?php echo session('status'); ?></b>
            </div>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="full-width">
            <div class="alert alert-danger">
                <i class="fa fa-check"></i> <b><?php echo session('error'); ?></b>
            </div>
        </div>
    <?php endif; ?>

    <div id="btnContainer">
        <div class="panel-heading">
            <div class="criar-pesquisar">
                <a id="botao-procurar-abrir" class="h_index"><b><i class="fa fa-search"></i></b></a>            
                <a id="botao-procurar-fechar" class="h_index"><b><i class="fa fa-search"></i></b></a>
            </div>
            <div class="criar-pesquisar">
                <a href="<?php echo e(route('contact.create')); ?>" style="float: right;">
                    <button type="button" class="btn btn-primary">NOVO CONTATO</button>
                </a>
            </div>
        </div>
        <button class="btnC" onclick="listView()"><i class="fa fa-bars"></i> List</button> 
        <button class="btnC active" onclick="gridView()"><i class="fa fa-th-large"></i> Grid</button>             
    </div>
    <div class="full-width" id="procurar-bloco">
        <div class="panel">
            <div class="panel-body">
                <form action="">
                    <h3>Procurar Contato</h3>
                    <div class="form-group col-md-6">
                        <input type="text" class="form-control input" name="name" maxlength="50" value="<?php echo e(isset($_GET['search']) ? $_GET['search'] : ''); ?>" placeholder="Nome" autocomplete="off">
                    </div>         

                    <div class="form-group col-md-6">
                        <input type="text" class="form-control input" id="telefone" maxlength="15" name="phone" value="<?php echo e(isset($_GET['search']) ? $_GET['search'] : ''); ?>" placeholder="Telefone" autocomplete="off">
                    </div>            

                    <div class="form-group col-sm-12">
                        <button type="submit" class="btn btn-primary">BUSCAR</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <br>

    <div class="row index">
        <?php $i = 0; ?>
        <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if ($i == 4){ $i = 0; }?>
            <div class="column background<?php echo e($i++); ?>">
                <div class="col-md-4 col-xs-12 col-sm-6 col-lg-4 image">
                    <img src="https://www.svgimages.com/svg-image/s5/man-passportsize-silhouette-icon-256x256.png" alt="stack photo" class="img">
                </div>
                <div class="col-md-8 col-xs-12 col-sm-6 col-lg-8 text">
                    <div class="contact_name">
                        <?php
                            $first_space = strpos($contact->name, " ");
                            $first_name = substr($contact->name, 0, $first_space);

                            $last_name = substr($contact->name, $first_space + 1, 50);
                            $second_space = strpos($last_name, " ");
                            if (!($second_space)) {
                                $second_name = substr($last_name, 0, 50);
                            } else {
                                $second_name = substr($last_name, 0, $second_space);
                            }
                            $name = $first_name." ".$second_name;
                        ?>
                        <h2 class="name_grid"><?php echo e($name); ?></h2>

                        <h2 class="name_list hidden"><?php echo e($contact->name); ?></h2>                        
                    </div>
                    <ul class="details">
                        <li class="list"><p><span class="fa fa-phone list-span"></span><?php echo e($contact->phone); ?></p></li>
                        <li class="list"><p><span class="fa fa-envelope list-span"></span><?php echo e($contact->email); ?></p></li>
                        <?php
                            $year = substr($contact->birthday, 0, 4);
                            $month = substr($contact->birthday, 5, 2);
                            $day = substr($contact->birthday, 8, 2);
                        ?>
                        <li class="list"><p><span class="fa fa-birthday-cake list-span"></span><?php echo e($day); ?>/<?php echo e($month); ?>/<?php echo e($year); ?></p></li>
                        <li class="list"><p>
                            <a class="options" href="<?php echo e(route('contact.edit', ['id' => $contact->id])); ?>"><span class="fa fa-edit"></span>&nbsp;Editar</a>&nbsp;&nbsp;|&nbsp;
                            <a class="options btn-delete" href="<?php echo e(route('contact.delete', ['id' => $contact->id])); ?>"><span class="fa fa-trash"></span>&nbsp;Excluir</a>
                        </p></li>
                    </ul>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<script>
    var elements = document.getElementsByClassName("column");
    var image = document.getElementsByClassName("image");
    var img = document.getElementsByClassName("img");
    var text = document.getElementsByClassName("text");

    var i;

    for (i = 0; i < elements.length; i++) {
        elements[i].style.width = "49%";
        image[i].style.width = "40%";
        image[i].style.height = "40%";
        // img[i].style.width = "100%";
        // img[i].style.height = "100%";
        text[i].style.width = "60%";
        text[i].style.height = "60%";
    }

    $('.img').attr('style', 'margin-top: 2%; width: 100%; height: 100%;');
    $('.details').attr('style', 'margin-top: 5%;');
    $('.list').attr('style', '');
    $('.list-span').attr('style', 'width: 50px;');

    // List View
    function listView() {
        for (i = 0; i < elements.length; i++) {
            elements[i].style.width = "98.8%";
            image[i].style.width = "20%";
            image[i].style.height = "20%";
            text[i].style.width = "80%";
            text[i].style.height = "80%";
        }
        $(document).ready(function(){
            $('.name_list').removeClass('hidden');
            $('.name_grid').addClass('hidden');
        });
        $('.img').attr('style', 'width: 70%; height: 70%;');
        $('.details').attr('style', 'margin-left: -3%;');
        $('.list').attr('style', 'display: inline-block; padding: 3%;');
        $('.list-span').attr('style', 'width: 30px;');
    }

    // Grid View
    function gridView() {
        for (i = 0; i < elements.length; i++) {
            elements[i].style.width = "49%";
            image[i].style.width = "40%";
            image[i].style.height = "40%";
            // img[i].style.width = "100%";
            // img[i].style.height = "100%";
            text[i].style.width = "60%";
            text[i].style.height = "60%";
        }
        $(document).ready(function(){
            $('.name_grid').removeClass('hidden');
            $('.name_list').addClass('hidden');
        });
        $('.img').attr('style', 'margin-top: 2%; width: 100%; height: 100%;');
        $('.details').attr('style', 'margin-top: 5%;');
        $('.list').attr('style', '');
        $('.list-span').attr('style', 'width: 50px;');
    }

    var container = document.getElementById("btnContainer");
    var btns = container.getElementsByClassName("btnC");
    for (var i = 0; i < btns.length; i++) {
        btns[i].addEventListener("click", function(){
            var current = document.getElementsByClassName("active");
            current[0].className = current[0].className.replace(" active", "");
            this.className += " active";
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>