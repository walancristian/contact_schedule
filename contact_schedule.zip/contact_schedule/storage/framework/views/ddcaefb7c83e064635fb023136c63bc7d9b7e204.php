<?php $__env->startSection('page_title', 'Cadastrar'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="col-sm-12">
        <a href="/home">
            <button type="button" class="btn btn-primary">VOLTAR</button>
        </a>
    </div>

    <div class="col-md-6 col-md-offset-3">
        <div class="panel">
            <div class="panel-heading">
                <h3><b>NOVO CONTATO</b></h3>
            </div>

            <div class="panel-body">
                <form method="post" action="">            
                    <div class="form-group col-sm-12">
                        <label>Nome:</label>   
                        <input class="form-control input" type="text" name="name" autocomplete="off">
                        <?php echo e(($errors->has('name')) ? $errors->first('name') : ''); ?>

                    </div>

                    <div class="form-group col-sm-12"> 
                        <label>E-mail:</label>  
                        <input class="form-control input" type="text" name="email" autocomplete="off">
                        <?php echo e(($errors->has('email')) ? $errors->first('email') : ''); ?>

                    </div>

                    <div class="form-group col-sm-6">
                        <label>Telefone:</label>   
                        <input class="form-control input" id="telefone" maxlength="15" type="text" name="phone" autocomplete="off">
                        <?php echo e(($errors->has('phone')) ? $errors->first('phone') : ''); ?>

                    </div>

                    <div class="form-group col-sm-6">
                        <label>Data de Nascimento:</label>
                        <input class="form-control input" type="date" name="birthday" autocomplete="off">
                        <?php echo e(($errors->has('birthday')) ? $errors->first('birthday') : ''); ?>

                    </div>

                    <div class="form-group col-sm-12">               
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <input type="submit" name="btn" class="btn btn-primary" value="CADASTRAR">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>