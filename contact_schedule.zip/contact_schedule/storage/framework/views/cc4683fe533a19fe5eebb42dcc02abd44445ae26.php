<?php $__env->startSection('page_title', 'Editar dados - Usuário'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <!-- <div class="col-sm-12">
        <a href="/home">
            <button type="button" class="btn btn-primary">VOLTAR</button>
        </a>
    </div> -->

    <div class="col-md-6 col-md-offset-3">
        <div class="panel">
            <div class="panel-heading">
                <h3 ><b>EDITAR PERFIL</b></h3>
            </div>

            <div class="panel-body">
                <form method="post" action="<?php echo e(route('user.update', ['id' => $user->id])); ?>">
                    <div class="form-group col-sm-12">
                        <label>Nome:</label>   
                        <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>">
                    </div>

                    <div class="form-group col-sm-12"> 
                        <label>E-mail:</label>  
                        <input type="text" class="form-control" name="email" value="<?php echo e($user->email); ?>">      
                    </div>

                    <div class="form-group col-sm-6"> 
                        <label>Senha:</label>  
                        <input type="password" class="form-control" name="password">
                    </div>

                    

                    <div class="form-group col-sm-12">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <input type="submit" name="btn" class="btn btn-primary" value="ATUALIZAR">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>