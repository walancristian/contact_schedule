<?php $__env->startSection('page_title', 'Detalhes Cadastro'); ?>

<?php $__env->startSection('content'); ?>

<div id="perfil" class="container">
    <?php if(session('status')): ?>
        <div class="full-width">
            <div class="alert alert-success">
                <i class="fa fa-check"></i> <b><?php echo session('status'); ?></b>
            </div>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="full-width">
            <div class="alert alert-danger">
                <i class="fa fa-check"></i> <b><?php echo session('error'); ?></b>
            </div>
        </div>
    <?php endif; ?>

    <div class="col-sm-12">
        <a href="/home">
            <button type="button" class="btn btn-primary">VOLTAR</button>
        </a>
    </div>

    <div class="col-md-6 col-md-offset-3">
        <div class="panel">
            <div class="panel-heading col-sm-12">
                <h3 class="col-sm-6"><b>PERFIL</b></h3>

                <div class="col-sm-6">
                    <div style="float: right; margin-top: 12%;">
                        <a id="edit-profile" href="#"><span class="fa fa-edit"></span>&nbsp;Editar</a>&nbsp;|&nbsp;
                        <a id="delete-profile" href="#"><span class="fa fa-trash"></span>&nbsp;Excluir</a>
                    </div>
                </div>
            </div>

            <div class="panel-body">
                <form method="post" action="">
                    <div class="form-group col-sm-6">
                        <strong>Nome:&nbsp;</strong><?php echo e($user->name); ?>

                    </div>

                    <div class="form-group col-sm-6"> 
                        <strong>E-mail:&nbsp;</strong><?php echo e($user->email); ?>      
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="container edit-profile hidden">
    <div class="col-md-6 col-md-offset-3">
        <div class="panel">
            <div class="panel-heading">
                <h3 class="col-sm-12">
                    <b>EDITAR PERFIL</b>

                    <div style="float: left;">
                        <a id="alter-password" href="#"><span class="fa fa-edit"></span>&nbsp;Alterar Senha</a>
                    </div>
                </h3>
            </div>

            <div class="panel-body">
                <form method="post" action="<?php echo e(route('user.update', ['id' => $user->id])); ?>">
                    <div class="form-group col-sm-12">
                        <label>Nome:</label>   
                        <input type="text" class="form-control input" name="name" maxlength="50" value="<?php echo e($user->name); ?>">
                    </div>

                    <div class="form-group col-sm-12"> 
                        <label>E-mail:</label>  
                        <input type="text" class="form-control input" name="email" maxlength="50" value="<?php echo e($user->email); ?>">      
                    </div>

                    <div class="form-group col-md-6"> 
                        <label>Senha:</label>  
                        <input type="password" class="form-control input" name="password" minlength="8" maxlength="20" placeholder="Mínimo 8 dígitos">
                    </div>

                    <div class="form-group col-md-6 alter-password hidden">
                        <label>Nova Senha:</label>
                        <input type="password" class="form-control input" name="newpassword" minlength="8" maxlength="20" placeholder="Mínimo 8 dígitos">               
                    </div>

                    <div class="col-sm-12"></div>

                    <div class="form-group col-md-6">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <input type="submit" name="btn" class="btn btn-primary" value="ATUALIZAR">
                    </div>

                    <div class="form-group col-md-6">
                        <input id="edit-cancel" type="button" name="btn-cancel" class="btn btn-primary btn-cancel" value="CANCELAR">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="container delete-profile hidden">
    <div class="col-md-6 col-md-offset-3">
        <div class="panel">
            <div class="panel-heading">
                <h3 class="col-sm-12"><b>EXCLUIR PERFIL</b></h3>
            </div>

            <div class="panel-body">
                <form method="post" action="<?php echo e(route('user.delete', ['id' => $user->id])); ?>">
                    <div class="form-group col-sm-12">
                        <label>Motivo:</label>   
                        <textarea type="text" class="form-control input" name="reason" rows="4" maxlength="500" placeholder="Por favor, nos descreva um breve motivo do porque não desejas mais utilizar nossa agenda de contatos! Obrigado!"></textarea>
                    </div>

                    <div class="form-group col-md-6"> 
                        <label>Senha:</label>  
                        <input type="password" class="form-control input" name="password" minlength="8" maxlength="20" placeholder="Mínimo 8 dígitos">
                    </div>

                    <div class="col-sm-12"></div>

                    <div class="form-group col-md-6">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <input type="submit" name="btn" class="btn btn-primary" value="EXCLUIR">
                    </div>

                    <div class="form-group col-md-6">
                        <input id="delete-cancel" type="button" name="btn-cancel" class="btn btn-primary btn-cancel" value="CANCELAR">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function(){
        $('#edit-profile').click(function(){
            $('.delete-profile').addClass('hidden');
            $('.edit-profile').removeClass('hidden');
        });

        $('#edit-cancel').click(function(){
            $('.edit-profile').addClass('hidden');
        });

        $('#alter-password').click(function(){
            $('.alter-password').removeClass('hidden');
        });

        $('#alter-password-cancel').click(function(){
            $('.alter-password').addClass('hidden');
        });
   
        $('#delete-profile').click(function(){
            $('.edit-profile').addClass('hidden');
            $('.delete-profile').removeClass('hidden');
        });

        $('#delete-cancel').click(function(){
            $('.delete-profile').addClass('hidden');
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>